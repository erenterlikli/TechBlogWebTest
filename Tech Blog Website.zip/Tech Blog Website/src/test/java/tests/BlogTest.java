package tests;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class BlogTest {
    private WebDriver driver;

    @BeforeMethod
    public static void setUp() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://techcrunch.com/");
    }

    @Test
    public void testLatestNews() {
        List<WebElement> newsList = driver.findElements(By.xpath("//div[@class='river river--homepage ']//div[contains(@class, 'post-block post-block--image post-block--unread')]"));

        for (WebElement news : newsList) {
            // Verify each news has an author
            WebElement author = news.findElement(By.xpath(".//span[@class='river-byline__authors']"));
            Assert.assertNotNull(author, "News item missing author");

            // Verify each news has an image
            WebElement image = news.findElement(By.xpath(".//figure[contains(@class, 'post-block__media')]//img"));
            Assert.assertNotNull(image, "News item missing image");
        }

        // Click the first news item to reach the full content
        WebElement firstNews = newsList.get(0);
        String newsTitle = firstNews.findElement(By.xpath(".//h2")).getText();
        firstNews.click();

        // Verify the browser title is the same as the news title
        String browserTitle = driver.getTitle();
        Assert.assertTrue(browserTitle.contains(newsTitle), "Browser title does not match news title");

        // Verify the links within the news content
        List<WebElement> links = driver.findElements(By.xpath("//div[@class='article-content']//a"));
        for (WebElement link : links) {
            Assert.assertNotNull(link.getAttribute("href"), "Link missing href attribute");
        }
    }

    @AfterMethod
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}
